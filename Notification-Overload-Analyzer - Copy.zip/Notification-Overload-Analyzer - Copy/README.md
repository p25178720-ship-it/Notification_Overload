# Notification Overload Analyzer

An analytics tool and interactive web dashboard for measuring digital interruption load, identifying distracting apps, and classifying cognitive overload.

## Project Structure
```text
Notification-Overload-Analyzer/
│
├── data/
│   └── notifications.csv       # Notification event logs
│
├── analyzer.py                 # Core analytics engine (NumPy + Pandas)
├── requirements.txt            # Python dependencies
├── README.md                   # Documentation and usage guide
└── website/
    ├── index.html              # Interactive client-side analytics dashboard
    └── summary_data.json       # Exported analytics summary from analyzer.py
```

## Features

### 1. Python Analytics Engine (`analyzer.py`)
Built with **NumPy** and **Pandas**, `analyzer.py` calculates:
- **Total Notifications**: Total volume of alerts across the logging window.
- **Notifications per App**: Frequency distribution and percentage breakdown.
- **Hourly Notification Patterns**: 24-hour distribution identifying morning, afternoon, and evening spikes.
- **Unread/Important Notification Ratio**: Ratio of unread alerts to high-importance alerts, unread percentage, and missed high-priority alerts.
- **Daily Overload Score (0–100)**: Multi-factor composite index based on daily volume, unimportant noise ratio, and unread friction.
- **Most Distracting Apps**: Ranked by a Distraction Index combining volume, non-importance, and unread rate.
- **Peak Notification Hour**: Identifies the single hour with the highest disruption frequency.
- **Overload Classification**: Qualitative tiers (`Low Overload (Optimal)`, `Moderate Overload (Manageable)`, `High Overload (Action Needed)`, and `Critical Overload (Severe)`).

### 2. Interactive Web Dashboard (`website/index.html`)
- **Visual Analytics**: Interactive 24-hour bar chart, app share doughnut chart, and daily overload trend line chart.
- **Interactive "Add New Data"**: Modal form to instantly append new notification logs and dynamically recalculate all metrics in real time.
- **CSV Import & Export**: Import your own notification CSV or download the updated dataset directly from the browser.
- **Notification Log Explorer**: Filterable and searchable event table.

## Quick Start

### Running the Python Analyzer
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the analyzer:
   ```bash
   python3 analyzer.py
   ```
   *By default, this analyzes `data/notifications.csv` and outputs `website/summary_data.json`.*

### Viewing the Dashboard
Simply open `website/index.html` in any modern web browser. No web server is required.
