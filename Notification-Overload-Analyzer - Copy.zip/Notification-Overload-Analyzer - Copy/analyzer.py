"""
Notification Overload Analyzer
Analyzes digital notification patterns, cognitive distraction, and overload scores
using NumPy and Pandas.
"""

import argparse
import json
import os
import sys
import numpy as np
import pandas as pd


class NotificationAnalyzer:
    """Core analytics engine for notification event logs."""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.df = self._load_and_preprocess()

    def _load_and_preprocess(self) -> pd.DataFrame:
        """Loads CSV and coerces timestamps and boolean flags."""
        if not os.path.exists(self.file_path):
            raise FileNotFoundError(f"Dataset not found at path: {self.file_path}")

        df = pd.read_csv(self.file_path)
        
        # Validate expected columns
        required_cols = {"timestamp", "app_name"}
        if not required_cols.issubset(df.columns):
            raise ValueError(f"CSV missing required columns. Required: {required_cols}")

        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df["date"] = df["timestamp"].dt.date
        df["hour"] = df["timestamp"].dt.hour
        df["day_name"] = df["timestamp"].dt.day_name()

        # Handle booleans gracefully
        if "is_read" in df.columns:
            df["is_read"] = df["is_read"].astype(bool)
        else:
            df["is_read"] = True

        if "is_important" in df.columns:
            df["is_important"] = df["is_important"].astype(bool)
        else:
            df["is_important"] = False

        if "category" not in df.columns:
            df["category"] = "General"

        return df

    def total_notifications(self) -> int:
        """Returns the total number of notifications logged."""
        return int(len(self.df))

    def notifications_per_app(self) -> pd.DataFrame:
        """Calculates volume and proportion of notifications by application."""
        app_counts = self.df["app_name"].value_counts().reset_index()
        app_counts.columns = ["app_name", "count"]
        total = len(self.df)
        app_counts["percentage"] = np.round((app_counts["count"] / total) * 100, 2)
        return app_counts

    def hourly_notification_patterns(self) -> pd.DataFrame:
        """Aggregates notification counts across all 24 hours of the day."""
        hourly = self.df.groupby("hour").size().reindex(range(24), fill_value=0).reset_index()
        hourly.columns = ["hour", "count"]
        total = max(len(self.df), 1)
        hourly["percentage"] = np.round((hourly["count"] / total) * 100, 2)
        return hourly

    def unread_important_ratio(self) -> dict:
        """
        Computes interaction and priority ratios:
        - unread count & unread ratio
        - important count & important ratio
        - unread to important ratio
        - high-priority missed (unread & important)
        """
        total = len(self.df)
        if total == 0:
            return {
                "total_unread": 0,
                "unread_percentage": 0.0,
                "total_important": 0,
                "important_percentage": 0.0,
                "unread_to_important_ratio": 0.0,
                "important_unread_count": 0
            }

        unread_count = int((~self.df["is_read"]).sum())
        important_count = int(self.df["is_important"].sum())
        important_unread = int((self.df["is_important"] & (~self.df["is_read"])).sum())

        ratio = np.round(unread_count / max(important_count, 1), 2)
        unread_pct = np.round((unread_count / total) * 100, 2)
        important_pct = np.round((important_count / total) * 100, 2)

        return {
            "total_unread": unread_count,
            "unread_percentage": float(unread_pct),
            "total_important": important_count,
            "important_percentage": float(important_pct),
            "unread_to_important_ratio": float(ratio),
            "important_unread_count": important_unread
        }

    def daily_overload_scores(self) -> pd.DataFrame:
        """
        Computes daily overload scores on a 0-100 scale:
        - Volume sub-score (0-50 pts): scaled against a baseline capacity of 100 notifications/day
        - Noise/Distraction sub-score (0-25 pts): proportion of non-important notifications
        - Friction/Unread sub-score (0-25 pts): accumulation of unread alerts
        """
        daily = self.df.groupby("date").agg(
            total_count=("notification_id", "count"),
            unread_count=("is_read", lambda s: (~s).sum()),
            unimportant_count=("is_important", lambda s: (~s).sum()),
        ).reset_index()

        # NumPy vectorized calculation of score components
        # 1. Volume score: min(50, (count / 100.0) * 50)
        volume_score = np.clip((daily["total_count"] / 100.0) * 50.0, 0, 50.0)

        # 2. Noise score: (unimportant / count) * 25.0
        noise_score = (daily["unimportant_count"] / np.maximum(daily["total_count"], 1)) * 25.0

        # 3. Friction score: (unread / count) * 25.0
        friction_score = (daily["unread_count"] / np.maximum(daily["total_count"], 1)) * 25.0

        daily["overload_score"] = np.round(volume_score + noise_score + friction_score, 1)
        daily["classification"] = daily["overload_score"].apply(self.classify_overload)
        daily["date"] = daily["date"].astype(str)

        return daily

    def most_distracting_apps(self, top_n: int = 5) -> pd.DataFrame:
        """
        Calculates a Distraction Index for each app:
        Distraction Index = Total Notifications * (1 - Important Ratio) * (1 + Unread Rate)
        Apps with large notification volumes that offer little utility rank highest.
        """
        grouped = self.df.groupby("app_name").agg(
            total=("notification_id", "count"),
            important=("is_important", "sum"),
            unread=("is_read", lambda s: (~s).sum()),
            category=("category", "first")
        ).reset_index()

        grouped["unimportant_ratio"] = 1.0 - (grouped["important"] / grouped["total"])
        grouped["unread_ratio"] = grouped["unread"] / grouped["total"]
        
        # Distraction Score formula using NumPy
        grouped["distraction_score"] = np.round(
            grouped["total"] * grouped["unimportant_ratio"] * (1.0 + grouped["unread_ratio"]),
            1
        )

        ranked = grouped.sort_values(by="distraction_score", ascending=False).head(top_n)
        return ranked[["app_name", "category", "total", "distraction_score", "unimportant_ratio", "unread_ratio"]]

    def peak_notification_hour(self) -> dict:
        """Identifies the peak hour of interruptions and volume."""
        hourly = self.df.groupby("hour").size()
        if hourly.empty:
            return {"peak_hour": 0, "peak_hour_label": "12 AM", "count": 0, "percentage": 0.0}

        peak_h = int(hourly.idxmax())
        peak_cnt = int(hourly.max())
        total = max(len(self.df), 1)
        pct = np.round((peak_cnt / total) * 100, 2)

        # Format label (e.g., 10 AM, 2 PM)
        period = "AM" if peak_h < 12 else "PM"
        display_h = 12 if peak_h % 12 == 0 else peak_h % 12
        label = f"{display_h}:00 {period}"

        return {
            "peak_hour": peak_h,
            "peak_hour_label": label,
            "count": peak_cnt,
            "percentage": float(pct)
        }

    @staticmethod
    def classify_overload(score: float) -> str:
        """Classifies an overload score into qualitative cognitive impact tiers."""
        if score < 40.0:
            return "Low Overload (Optimal)"
        elif score < 70.0:
            return "Moderate Overload (Manageable)"
        elif score < 85.0:
            return "High Overload (Action Needed)"
        else:
            return "Critical Overload (Severe)"

    def generate_summary(self) -> dict:
        """Compiles all analytics into a comprehensive dictionary."""
        total = self.total_notifications()
        apps_df = self.notifications_per_app()
        hourly_df = self.hourly_notification_patterns()
        ratios = self.unread_important_ratio()
        daily_df = self.daily_overload_scores()
        distracting_df = self.most_distracting_apps(top_n=5)
        peak_hr = self.peak_notification_hour()

        avg_daily_score = float(np.round(daily_df["overload_score"].mean(), 1)) if not daily_df.empty else 0.0
        overall_classification = self.classify_overload(avg_daily_score)

        return {
            "overview": {
                "total_notifications": total,
                "total_days_logged": int(daily_df["date"].nunique()) if not daily_df.empty else 0,
                "avg_daily_notifications": float(np.round(total / max(daily_df["date"].nunique(), 1), 1)),
                "avg_daily_overload_score": avg_daily_score,
                "overall_classification": overall_classification,
                "peak_notification_hour": peak_hr
            },
            "unread_important_metrics": ratios,
            "notifications_per_app": apps_df.to_dict(orient="records"),
            "hourly_patterns": hourly_df.to_dict(orient="records"),
            "daily_scores": daily_df.to_dict(orient="records"),
            "most_distracting_apps": distracting_df.to_dict(orient="records")
        }


def print_cli_report(summary: dict):
    """Outputs a clean terminal dashboard for the analyzer."""
    overview = summary["overview"]
    ratios = summary["unread_important_metrics"]

    print("=" * 65)
    print("       NOTIFICATION OVERLOAD ANALYZER - SUMMARY REPORT       ")
    print("=" * 65)
    print(f"Total Notifications Logged : {overview['total_notifications']}")
    print(f"Days Analyzed              : {overview['total_days_logged']} days")
    print(f"Daily Average Volume       : {overview['avg_daily_notifications']} alerts/day")
    print(f"Average Overload Score     : {overview['avg_daily_overload_score']}/100")
    print(f"Overall Classification     : {overview['overall_classification']}")
    print(f"Peak Notification Hour     : {overview['peak_notification_hour']['peak_hour_label']} "
          f"({overview['peak_notification_hour']['count']} notifications, "
          f"{overview['peak_notification_hour']['percentage']}%)")
    print("-" * 65)
    print("INTERACTION & IMPORTANCE RATIOS:")
    print(f"  • Unread Alerts          : {ratios['total_unread']} ({ratios['unread_percentage']}%)")
    print(f"  • Important Alerts       : {ratios['total_important']} ({ratios['important_percentage']}%)")
    print(f"  • Unread to Important    : {ratios['unread_to_important_ratio']}x")
    print(f"  • Missed Important Alerts: {ratios['important_unread_count']}")
    print("-" * 65)
    print("TOP 5 MOST DISTRACTING APPS (by Distraction Index):")
    for i, app in enumerate(summary["most_distracting_apps"], 1):
        print(f"  {i}. {app['app_name']:<12} | Category: {app['category']:<12} | "
              f"Total: {app['total']:<4} | Score: {app['distraction_score']}")
    print("-" * 65)
    print("DAILY OVERLOAD BREAKDOWN:")
    for day in summary["daily_scores"]:
        print(f"  {day['date']} : Count={day['total_count']:<3} | "
              f"Score={day['overload_score']:<4} | {day['classification']}")
    print("=" * 65)


def main():
    parser = argparse.ArgumentParser(description="Analyze notification logs for digital overload.")
    parser.add_argument("--csv", default="data/notifications.csv", help="Path to notifications.csv")
    parser.add_argument("--json-out", default="website/summary_data.json", help="Path to export JSON summary")
    args = parser.parse_args()

    base_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(base_dir, args.csv) if not os.path.isabs(args.csv) else args.csv
    json_path = os.path.join(base_dir, args.json_out) if not os.path.isabs(args.json_out) else args.json_out

    try:
        analyzer = NotificationAnalyzer(csv_path)
        summary = analyzer.generate_summary()
        print_cli_report(summary)

        # Save JSON output for the website
        os.makedirs(os.path.dirname(json_path), exist_ok=True)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(f"\n[+] Analytics successfully exported to: {json_path}")

    except Exception as e:
        print(f"Error during analysis: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
